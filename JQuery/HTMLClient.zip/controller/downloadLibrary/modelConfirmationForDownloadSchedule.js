﻿define(["knockout", "knockout.validation", "jQuery.base64", "constants", "globalFunction", "appEnum", , "bootstrap", "bootstrapDatePicker", "moment", "spinner"], function (ko) {


    return function downloadConfirmationViewModel() {
        var self = this;
        seti18nResourceData(document, resourceStorage);
    };

});