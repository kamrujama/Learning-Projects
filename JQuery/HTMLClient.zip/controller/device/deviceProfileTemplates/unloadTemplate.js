﻿define(["knockout", "knockout.validation", "jQuery.base64", "constants", "globalFunction", "appEnum"], function (ko) {

    return function advanceSearchViewModel() {

        var self = this;
    };
});