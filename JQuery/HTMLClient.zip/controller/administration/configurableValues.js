﻿define(["knockout"], function (ko) {

    return function DashBoardViewModel() {

        var self = this;

    }

});